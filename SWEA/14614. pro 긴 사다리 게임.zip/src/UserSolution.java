import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.TreeMap;

class UserSolution
{
    long[] time;
    ArrayList<HashMap<Integer,Integer>> map;
    ArrayList<ArrayList<Integer>> keyListArr;
    boolean[] updated;

    public long[] count(){
        return time;
    }

	public void init()
	{
        map = new ArrayList<>();
        updated = new boolean[101];
        keyListArr = new ArrayList<>();
        for(int i=0;i<101;i++){
            keyListArr.add(new ArrayList<>());
        }
        for(int i=0;i<101;i++){
            map.add(new HashMap<>());
        }
        time = new long[4];
	}

	public void add(int mX, int mY)
	{   
        long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기
        
        //실험할 코드 추가       

        updated[mX] = true;
        updated[mX+1] = true;
        map.get(mX).put(mY, 1);
        map.get(mX+1).put(mY, -1);

        long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
        long secDiffTime = (afterTime - beforeTime); //두 시간에 차 계산
        time[0]+=secDiffTime;
        
	}

	public void remove(int mX, int mY)
	{
        long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기
        updated[mX] = true;
        updated[mX+1] = true;
        map.get(mX).remove(mY);
        map.get(mX+1).remove(mY);

        long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
        long secDiffTime = (afterTime - beforeTime); //두 시간에 차 계산
        time[1]+=secDiffTime;
	}

	public int numberOfCross(int mID)
	{
        long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기
        int x = mID;
        int y = 0;
        int cnt = 0;
        while(y!=1000000000){                     
            //keyList = new ArrayList<>(map.get(x).keySet());
            if(updated[x]){
                keyListArr.set(x, new ArrayList<>(map.get(x).keySet()));  
                Collections.sort(keyListArr.get(x));
                //System.out.println(x+" "+keyList);
                updated[x] = false;
            }
            ArrayList<Integer> keyList = keyListArr.get(x);
            int left = 0;
            int right = keyList.size();
            int mid;
            while(left<right){
                mid = (left+right)/2;
                if(keyList.get(mid)>y){
                    right = mid;
                }else{
                    left = mid+1;
                }
            }
            if(right<keyList.size()){
                x+=map.get(x).get(keyList.get(right));
                cnt++;
                y = keyList.get(right);
            }else{
                y = 1000000000;
            }
        }

        long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
        long secDiffTime = (afterTime - beforeTime); //두 시간에 차 계산
        time[2]+=secDiffTime;
		return cnt;
	}

	public int participant(int mX, int mY)
	{
        long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기
        int x = mX;
        int y = mY;
        while(y!=0){            
            //System.out.println("x: "+x+" y: "+y);            
            //keyList = new ArrayList<>(map.get(x).keySet());
            if(updated[x]){
                keyListArr.set(x, new ArrayList<>(map.get(x).keySet()));
                Collections.sort(keyListArr.get(x));
                //System.out.println(x+" "+keyList);
                updated[x] = false;
            }            
            ArrayList<Integer> keyList = keyListArr.get(x);
            //System.out.println(x+" "+keyList);
            if(keyList.size()==0){
                y=0;                
            }else if(keyList.size()==1){     
                if(keyList.get(0)<y){
                    x+=map.get(x).get(keyList.get(0));
                    y = keyList.get(0);
                }else{
                    y=0;
                }                
            }
            else{
                //System.out.println("else x: "+x);
                int left = 0;
                int right = keyList.size();
                int mid;
                while(left+1<right){
                    mid = (left+right)/2;
                    if(keyList.get(mid)<y){
                        left = mid;
                    }else{
                        right = mid;                        
                    }
                }

                int next = left;
                if(next==0){
                    if(keyList.get(next)<y){                        
                        x+=map.get(x).get(keyList.get(next));
                        y = keyList.get(next);
                    }else{
                        y = 0;
                    }
                }else if(next<keyList.size()){
                    x+=map.get(x).get(keyList.get(next));
                    y = keyList.get(next);
                }else if(next==keyList.size()){
                    x+=map.get(x).get(keyList.get(next-1));
                    y = keyList.get(next-1);
                }
                else{
                    y = 0;
                }
            }            
        }

        long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
        long secDiffTime = (afterTime - beforeTime); //두 시간에 차 계산
        time[3]+=secDiffTime;
		return x;
	}
}
